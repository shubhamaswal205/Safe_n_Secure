package com.example.womensafety;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;


public class UpdateContacts extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, com.google.android.gms.location.LocationListener  {
Button contact1,contact2,contact3,contact4,remove1,remove2,remove3,remove4;
TextView mob1,mob2,mob3,mob4;
SharedPreferences sp;

    private static final String TAG = "MainActivity";
    private TextView mLatitudeTextView;
    private TextView mLongitudeTextView;
    private GoogleApiClient mGoogleApiClient;
    private Location mLocation;
    private LocationManager mLocationManager;

    private LocationRequest mLocationRequest;
    private com.google.android.gms.location.LocationListener listener;
    private long UPDATE_INTERVAL = 2 * 1000;  /* 10 secs */
    private long FASTEST_INTERVAL = 2000; /* 2 sec */

    private LocationManager locationManager;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_contacts);
        contact1 = findViewById(R.id.c1);
        contact2 = findViewById(R.id.c2);
        contact3 = findViewById(R.id.c3);
        contact4 = findViewById(R.id.c4);

        remove1 = findViewById(R.id.r1);
        remove2 = findViewById(R.id.r2);
        remove3 = findViewById(R.id.r3);
        remove4 = findViewById(R.id.r4);

        mob1 = findViewById(R.id.num1);
        mob2 = findViewById(R.id.num2);
        mob3 = findViewById(R.id.num3);
        mob4 = findViewById(R.id.num4);

        load();


   /*
        mLatitudeTextView = (TextView) findViewById((R.id.latitude_textview));
        mLongitudeTextView = (TextView) findViewById((R.id.longitude_textview));

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();

        mLocationManager = (LocationManager)this.getSystemService(Context.LOCATION_SERVICE);

        checkLocation(); //check whether location service is enable or not in your  phone
*/


    }
    public void updContacts(View view)
    {
        int choose_button;
        if (view.getId() == R.id.c1)
            choose_button = 1;
        else if (view.getId() == R.id.c2)
            choose_button = 2;
        else if (view.getId() == R.id.c3)
            choose_button = 3;
        else
            choose_button = 4;

        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
        startActivityForResult(intent,choose_button);
    }
    public void onActivityResult(int reqCode, int resultCode, Intent data) {
        super.onActivityResult(reqCode, resultCode, data);
        if(resultCode == 0)
            return ;
       String cNumber=null;
        String name = null;

        if (resultCode == Activity.RESULT_OK) {

            Uri contactData = data.getData();
            Cursor c =  managedQuery(contactData, null, null, null, null);
            if (c.moveToFirst()) {


                String id =c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts._ID));

                String hasPhone =c.getString(c.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));

                if (hasPhone.equalsIgnoreCase("1")) {
                    Cursor phones = getContentResolver().query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" = "+ id,
                            null, null);
                    phones.moveToFirst();
                    cNumber = phones.getString(phones.getColumnIndex("data1"));
                    System.out.println("number is:"+cNumber);
                }
                name = c.getString(c.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));


            }
        }
        storeData(name,cNumber,reqCode);
        showSelectedNumber(cNumber);
        switch (reqCode)
        {
            case 1:
                contact1.setText(name);
                break;
            case 2:
                contact2.setText(name);
                break;
            case 3:
                contact3.setText(name);
                break;
            case 4:
                contact4.setText(name);
                break;
            }
            load();
    }
    public void showSelectedNumber(String number) {
        Toast.makeText(this,"Selected contact Number: " + number, Toast.LENGTH_LONG).show();
        //   CoordinatorLayout cl = findViewById(R.id.coordinatorLayout);
    }
    public void storeData(String name,String cNumber,int choose_button)
    {
        sp = getSharedPreferences("Contacts", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed= sp.edit();
        ed.putString(Integer.toString(choose_button),cNumber);
        ed.putString(Integer.toString(choose_button)+"_1",name);
        ed.commit();
        Toast.makeText(this,"Data saved successfully",Toast.LENGTH_SHORT).show();
    }
    public void load()
    {
        sp = getSharedPreferences("Contacts", Context.MODE_PRIVATE);

        String s1= sp.getString("1_1","choose Contact 1");
        String s2= sp.getString("2_1","choose Contact 2");
        String s3= sp.getString("3_1","choose Contact 3");
        String s4= sp.getString("4_1","choose Contact 4");

        String n1 = sp.getString("1","No number");
        String n2 = sp.getString("2","No number");
        String n3 = sp.getString("3","No number");
        String n4 = sp.getString("4","No number");

        contact1.setText(s1);
        contact2.setText(s2);
        contact3.setText(s3);
        contact4.setText(s4);

        mob1.setText(n1);
        mob2.setText(n2);
        mob3.setText(n3);
        mob4.setText(n4);

        return;

    }

    public void deleteContact(View v) {
        String s;
        SharedPreferences.Editor ed = sp.edit();
        switch (v.getId()) {
            case R.id.r1:
                s = sp.getString("1_1", "choose Contact 1");
                if (s != "choose Contact 1")
                {
                    ed.remove("1_1");
                    ed.commit();
                    ed.remove("1");
                    ed.commit();
                    contact1.setText("choose Contact 1");
                    mob1.setText("No number");
                    Toast.makeText(getApplicationContext(),"Contact Removed",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.r2:
                s = sp.getString("2_1", "choose Contact 2");
                if (s != "choose Contact 2") {
                    ed.remove("2_1");
                    ed.commit();
                    ed.remove("2");
                    ed.commit();
                    contact2.setText("choose Contact 2");
                    mob2.setText("No number");
                    Toast.makeText(getApplicationContext(),"Contact Removed",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.r3:
                s = sp.getString("3_1", "choose Contact 3");
                if (s != "choose Contact 3") {
                    ed.remove("3_1");
                    ed.commit();
                    ed.remove("3");
                    ed.commit();
                    contact3.setText("choose Contact 3");
                    mob3.setText("No number");
                    Toast.makeText(getApplicationContext(),"Contact Removed",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.r4:
                s = sp.getString("4_1", "choose Contact 4");
                if (s != "choose Contact 4") {
                    ed.remove("4_1");
                    ed.commit();
                    ed.remove("4");
                    ed.commit();
                    contact4.setText("choose Contact 4");
                    mob4.setText("No number");
                    Toast.makeText(getApplicationContext(),"Contact Removed",Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {

    }

/*    public String getLatitude()
    {

    }

    public String getLongitude()
    {
        String longi = null;

        return longi;
    }

    public void dispLati(View view)
    {
        Toast.makeText(this,getLatitude(),Toast.LENGTH_SHORT).show();
    }
    public void dispLongi(View view)
    {
        Toast.makeText(this,getLongitude(),Toast.LENGTH_SHORT).show();
    }
   */
}

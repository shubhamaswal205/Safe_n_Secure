package com.example.womensafety;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends UpdateContacts {
Button updateContacts,sendLoc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        updateContacts = findViewById(R.id.b1);
        sendLoc = findViewById(R.id.b2);

        updateContacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),UpdateContacts.class);
                startActivity(intent);
            }
        });

        sendLoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    SharedPreferences sp = getSharedPreferences("Contacts", MODE_PRIVATE);
                    String s1 = sp.getString("1", "chooseContact1");
                    String s2 = sp.getString("2", "chooseContact2");
                    String s3 = sp.getString("3", "chooseContact3");
                    String s4 = sp.getString("4", "chooseContact4");

                    SmsManager smgr = SmsManager.getDefault();
                    if (s1 == "chooseContact1" && s2 == "chooseContact2" && s3 == "chooseContact3" && s4 == "chooseContact4")
                        Toast.makeText(MainActivity.this, "  No contacts selected.\n" +"PLEASE SET CONTACTS", Toast.LENGTH_SHORT).show();
                    else {
                        String latitude = "";
                        String longitude = "";
                    if (s1 != "chooseContact1")
                            smgr.sendTextMessage(s1, null, "1\n"+"https://www.google.com/maps/search/?api=1&query="+latitude+","+longitude, null, null);
                        if (s1 != "chooseContact2")
                            smgr.sendTextMessage(s2, null, "2", null, null);
                        if (s1 != "chooseContact3")
                            smgr.sendTextMessage(s3, null, "3", null, null);
                        if (s1 != "chooseContact4")
                            smgr.sendTextMessage(s4, null, "4", null, null);
                        Toast.makeText(MainActivity.this, "SMS Sent Successfully" + s1 + s2 + s3 + s4, Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception e){
                    Toast.makeText(MainActivity.this, "SMS Failed to Send, Make sure all permission are given to app from settings", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
